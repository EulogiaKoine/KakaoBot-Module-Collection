"use strict"
module.exports = function(path, r_inspire){
r_inspire("format")
r_inspire('countSplitLeft')
r_inspire('countSplitRight')
r_inspire('similars')
return {}
}