"use strict"
module.exports = function(path, r_inspire){
return {
    Chat: r_inspire('Chat').Chat
}
}